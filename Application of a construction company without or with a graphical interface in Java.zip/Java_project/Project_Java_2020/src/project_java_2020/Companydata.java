/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_java_2020;

import java.util.Date;

/**
 *
 * @author panos
 */
public abstract class Companydata // abstract κλάση όπου οι κλάσεις μας θα κληρωνομούνε τα στοιχεία που απαιτούνται να έχουν , όπου πολλά απο αυτά είναι ίδια.

{
    
protected String firstname;
protected String lastname;
protected Date birthdate;
protected String familysituation;
protected int numberofchildren;
protected int yearofrecruitment;
protected String speciality;
protected int levelofeducation;
protected String nameofdepartment;
protected Date dateofwithdrawal;   
protected String shortdescription;
protected String nameofwork;
protected double grossrevenueofcompany;
protected double  costsforlogisticalinfrastructure;
protected double costsforotheroperatingexpenses;   
protected Date startdate;
protected Date expirationdate;
    
}
